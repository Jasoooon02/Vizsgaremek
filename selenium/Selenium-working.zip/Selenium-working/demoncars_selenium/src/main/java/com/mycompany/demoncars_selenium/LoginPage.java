
package com.mycompany.demoncars_selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;

public class LoginPage {
    private final WebDriver driver;
    private final WebDriverWait wait;

    // Lokátorok a bejelentkezéshez
    private final By usernameField = By.id("user");
    private final By passwordField = By.id("password");
    private final By loginButton = By.cssSelector("button.button[type='submit']");
    
    // Lokátorok a regisztrációhoz
    private final By regEmailField = By.id("reg-email");
    private final By regUsernameField = By.id("reg-username");
    private final By regPasswordField = By.id("reg-password");
    private final By confirmPasswordField = By.id("confirm-password");
    private final By registerButton = By.cssSelector("#register-form button.button");
    
    // Lokátorok az elfelejtett jelszóhoz
    private final By forgotPasswordLink = By.id("forgot-password-link");
    private final By fpUsernameField = By.id("fp-username");
    private final By fpEmailField = By.id("fp-email");
    private final By resetPasswordButton = By.cssSelector("#forgot-password-form button.button");
    private final By recoverUsernameButton = By.cssSelector("#forgot-username-form button.button");
    private final By modalCloseButton = By.className("close");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    // Bejelentkezési metódusok
    public void enterUsername(String username) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(usernameField)).sendKeys(username);
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void clickLoginButton() {
        driver.findElement(loginButton).click();
    }

    // Regisztrációs metódusok
    public void enterRegEmail(String email) {
        driver.findElement(regEmailField).sendKeys(email);
    }

    public void enterRegUsername(String username) {
        driver.findElement(regUsernameField).sendKeys(username);
    }

    public void enterRegPassword(String password) {
        driver.findElement(regPasswordField).sendKeys(password);
    }

    public void enterConfirmPassword(String password) {
        driver.findElement(confirmPasswordField).sendKeys(password);
    }

    public void clickRegisterButton() {
        driver.findElement(registerButton).click();
    }

    // Elfelejtett jelszó metódusok
    public void openForgotPasswordModal() {
        driver.findElement(forgotPasswordLink).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(fpUsernameField));
    }

    public void enterFpUsername(String username) {
        driver.findElement(fpUsernameField).sendKeys(username);
    }

    public void enterFpEmail(String email) {
        driver.findElement(fpEmailField).sendKeys(email);
    }

    public void clickResetPasswordButton() {
        driver.findElement(resetPasswordButton).click();
    }

    public void clickRecoverUsernameButton() {
        driver.findElement(recoverUsernameButton).click();
    }

    public void closeModal() {
        driver.findElement(modalCloseButton).click();
    }
}




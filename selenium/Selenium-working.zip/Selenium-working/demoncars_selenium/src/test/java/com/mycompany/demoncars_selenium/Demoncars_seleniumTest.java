
package com.mycompany.demoncars_selenium;

import org.junit.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.junit.Assert.*;

public class Demoncars_seleniumTest {
    private WebDriver driver;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:/utak/chromedriver.exe");
        driver = new ChromeDriver();
    }

    @Test
    public void testMain() {
        driver.get("https://demoncars.online");
        assertEquals("Demon Cars", driver.getTitle());  // <- Ellenőrzés
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }
}


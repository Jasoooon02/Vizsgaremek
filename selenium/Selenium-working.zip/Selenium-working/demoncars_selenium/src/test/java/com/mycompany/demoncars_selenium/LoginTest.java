package com.mycompany.demoncars_selenium;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import static org.junit.Assert.*;
import org.openqa.selenium.edge.EdgeDriver;

public class LoginTest {
    private WebDriver driver;
    private LoginPage loginPage;

    @Before
    public void setUp() {
        
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://demoncars.online/");
        loginPage = new LoginPage(driver);
    }

    @Test
    public void testSuccessfulLogin() {
        loginPage.enterUsername("tesztfelhasznalo");
        loginPage.enterPassword("jelszo123");
        loginPage.clickLoginButton();
        
        // Itt ellenőrizd a sikeres bejelentkezés utáni átirányítást
        assertNotEquals("https://demoncars.online/", driver.getCurrentUrl());
    }

    @Test
    public void testRegistrationWithValidData() {
        loginPage.enterRegEmail("teszt@example.com");
        loginPage.enterRegUsername("ujfelhasznalo");
        loginPage.enterRegPassword("Jelszo123!");
        loginPage.enterConfirmPassword("Jelszo123!");
        loginPage.clickRegisterButton();
        
        // Itt ellenőrizd a sikeres regisztráció utáni átirányítást
        assertTrue(driver.getCurrentUrl().contains("success"));
    }

    @Test
    public void testPasswordRecovery() {
        loginPage.openForgotPasswordModal();
        loginPage.enterFpUsername("elfelejtett_felhasznalo");
        loginPage.enterFpEmail("email@example.com");
        loginPage.clickResetPasswordButton();
        
        // Itt ellenőrizd a sikeres jelszó-visszaállítási üzenetet
        assertTrue(driver.getPageSource().contains("jelszó visszaállítási"));
    }

    @After
    public void tearDown() {
        //if (driver != null) {
           // driver.quit();
        //}
    }
}
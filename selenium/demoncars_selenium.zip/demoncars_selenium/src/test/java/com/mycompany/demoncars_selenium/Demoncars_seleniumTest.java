/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.demoncars_selenium;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author bubum
 */
public class Demoncars_seleniumTest {
    private static WebDriver driver;
    public Demoncars_seleniumTest() {
        
    }

    @org.junit.BeforeClass
    public static void setUpClass() throws Exception {
        driver = new ChromeDriver();
    }

    @org.junit.AfterClass
    public static void tearDownClass() throws Exception {
    }

    @org.junit.Before
    public void setUp() throws Exception {
    }

    @org.junit.After
    public void tearDown() throws Exception {
    }

    /**
     * Test of main method, of class Demoncars_selenium.
     */
    @org.junit.Test
    public void testMain() {
        driver.get("https://demoncars.online");
    }
    
}

package com.mycompany.demoncars_selenium;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginFunctionalityTest extends TestBase {
    
    @Test
    public void testSuccessfulLogin() {
        loginPage.enterUsername("tesztfelhasznalo");
        loginPage.enterPassword("jelszo123");
        loginPage.clickLoginButton();
        
        assertNotEquals("https://demoncars.online/", driver.getCurrentUrl());
    }

    @Test
    public void testLoginWithInvalidCredentials() {
        loginPage.enterUsername("rosszfelhasznalo");
        loginPage.enterPassword("rosszjelszo");
        loginPage.clickLoginButton();
        
        assertTrue(driver.getPageSource().contains("Hibás felhasználónév vagy jelszó"));
    }
}
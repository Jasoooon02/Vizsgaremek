
package com.mycompany.demoncars_selenium;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Demoncars_seleniumTest {
    private static WebDriver driver;
    public Demoncars_seleniumTest() {
        
    }

    @org.junit.BeforeClass
    public static void setUpClass() throws Exception {
        driver = new ChromeDriver();
    }

    @org.junit.AfterClass
    public static void tearDownClass() throws Exception {
    }

    @org.junit.Before
    public void setUp() throws Exception {
    }

    @org.junit.After
    public void tearDown() throws Exception {
    }

    
    @org.junit.Test
    public void testMain() {
        driver.get("https://demoncars.online");
    }
    






}






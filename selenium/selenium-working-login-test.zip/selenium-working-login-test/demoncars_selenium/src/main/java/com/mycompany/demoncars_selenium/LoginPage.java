
package com.mycompany.demoncars_selenium;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
        
    private WebDriver driver;

    // Lokátorok
    private By usernameField = By.id("user");
    private By passwordField = By.id("password");
    private By loginButton = By.id("button");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    // Műveletek
    public void enterUsername(String username) {
        try {
        driver.findElement(usernameField).sendKeys(username);
    } catch (Exception e) {
        System.out.println("❌ Nem sikerült beírni a felhasználónevet!");
        e.printStackTrace();
    }
    }

    public void enterPassword(String password) {
        driver.findElement(passwordField).sendKeys(password);
    }

    public void clickLoginButton() {
        driver.findElement(loginButton).click();
    }
    

    
    
}





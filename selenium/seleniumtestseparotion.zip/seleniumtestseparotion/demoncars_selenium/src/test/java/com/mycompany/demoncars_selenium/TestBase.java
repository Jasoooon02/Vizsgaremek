package com.mycompany.demoncars_selenium;

import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class TestBase {
    protected WebDriver driver;
    protected LoginPage loginPage;

    @Before
    public void setUp() {
        System.setProperty("webdriver.edge.driver", "C:/utak/msedgedriver.exe");
        driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://demoncars.online/");
        loginPage = new LoginPage(driver);
    }

    @After
    public void tearDown() {
        // Nem zárjuk be a böngészőt
    }
}

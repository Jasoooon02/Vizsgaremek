package com.mycompany.demoncars_selenium;

import org.junit.Test;
import static org.junit.Assert.*;

public class PasswordRecoveryTest extends TestBase {
    
    @Test
    public void testPasswordRecovery() {
        loginPage.openForgotPasswordModal();
        loginPage.enterFpUsername("elfelejtett_felhasznalo");
        loginPage.enterFpEmail("email@example.com");
        loginPage.clickResetPasswordButton();
        
        assertTrue(driver.getPageSource().contains("jelszó visszaállítási"));
    }

    @Test
    public void testUsernameRecovery() {
        loginPage.openForgotPasswordModal();
        loginPage.enterFpEmail("regi@email.com");
        loginPage.clickRecoverUsernameButton();
        
        assertTrue(driver.getPageSource().contains("felhasználónév visszaállítási"));
    }
}
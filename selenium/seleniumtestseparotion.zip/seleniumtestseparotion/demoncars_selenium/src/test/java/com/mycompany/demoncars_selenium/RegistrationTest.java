package com.mycompany.demoncars_selenium;

import org.junit.Test;
import static org.junit.Assert.*;

public class RegistrationTest extends TestBase {
    
    @Test
    public void testRegistrationWithValidData() {
        loginPage.enterRegEmail("teszt@example.com");
        loginPage.enterRegUsername("ujfelhasznalo");
        loginPage.enterRegPassword("Jelszo123!");
        loginPage.enterConfirmPassword("Jelszo123!");
        loginPage.clickRegisterButton();
        
        assertTrue(driver.getCurrentUrl().contains("success"));
    }

    @Test
    public void testRegistrationWithExistingEmail() {
        loginPage.enterRegEmail("letezo@email.com");
        loginPage.enterRegUsername("ujfelhasznalo2");
        loginPage.enterRegPassword("Jelszo123!");
        loginPage.enterConfirmPassword("Jelszo123!");
        loginPage.clickRegisterButton();
        
        assertTrue(driver.getPageSource().contains("Ez az email cím már regisztrálva van"));
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.demoncars_selenium;

/**
 *
 * @author bubum
 */
public class Demoncars_selenium {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

package com.mycompany.demoncars;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.By;


public class DemoncarswithoutloginTest {
    public static void main(String[] args) {
        System.setProperty("webdriver.edge.driver", "edgedriver.exe");
        WebDriver driver = new EdgeDriver();
        System.out.println("Edge böngésző elindult");

        try {
            driver.get("https://www.demoncars.online/index.html");
            System.out.println("Oldal betöltve");

            driver.findElement(By.id("user-icon")).click();
            System.out.println("User ikonra kattintottam");

            driver.findElement(By.xpath("//button[contains(@onclick,'index.html')]")).click();
            System.out.println("Vissza gombra kattintottam");

            System.out.println("VÉGEREDMÉNY: " + driver.getCurrentUrl());

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            driver.quit();
            System.out.println("Böngésző bezárva");
        }
    }
}
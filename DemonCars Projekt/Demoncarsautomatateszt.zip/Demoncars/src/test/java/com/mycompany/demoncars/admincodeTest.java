/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.demoncars;


import java.time.Duration;
import org.openqa.selenium.*;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.edge.EdgeDriver;
public class admincodeTest {
    
private WebDriver driver;
  
  private StringBuffer verificationErrors = new StringBuffer();
  JavascriptExecutor js;
  @BeforeEach
  public void setUp() throws Exception {
    System.setProperty("webdriver.chrome.driver", "");
    driver = new EdgeDriver();
    
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
    js = (JavascriptExecutor) driver;
  }

  @Test
  public void testAdmin() throws Exception {
    driver.get("https://www.demoncars.online/index.html");
    driver.findElement(By.id("user-icon")).click();
    driver.get("https://www.demoncars.online/login.html");
    driver.findElement(By.id("reg-email")).click();
    driver.findElement(By.id("reg-email")).clear();
    driver.findElement(By.id("reg-email")).sendKeys("teszt.elek@gmail.com");
    driver.findElement(By.id("reg-username")).click();
    driver.findElement(By.id("reg-username")).clear();
    driver.findElement(By.id("reg-username")).sendKeys("Teszt Elek");
    driver.findElement(By.id("reg-password")).click();
    driver.findElement(By.id("reg-password")).clear();
    driver.findElement(By.id("reg-password")).sendKeys("Tesztjelszo123!");
    driver.findElement(By.id("confirm-password")).click();
    driver.findElement(By.id("confirm-password")).clear();
    driver.findElement(By.id("confirm-password")).sendKeys("Tesztjelszo123!");
    driver.findElement(By.id("is-admin")).click();
    driver.findElement(By.id("admin-code")).click();
    driver.findElement(By.id("admin-code")).clear();
    driver.findElement(By.id("admin-code")).sendKeys("22087078022");
    driver.findElement(By.xpath("//form[@id='register-form']/button")).click();
    driver.get("https://www.demoncars.online/register.php");
    
  }

  @AfterEach
  public void tearDown() throws Exception {

    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  
}

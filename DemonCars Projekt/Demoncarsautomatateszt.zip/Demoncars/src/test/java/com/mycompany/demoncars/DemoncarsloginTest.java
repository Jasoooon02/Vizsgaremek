
package com.mycompany.demoncars;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.WebDriver;
import org.junit.jupiter.api.Test;



public class DemoncarsloginTest {

    private WebDriver driver;

    @BeforeEach
    public void startBrowser() {
        System.setProperty("webdriver.Edge.driver", "Edgedriver.exe");
        driver = new EdgeDriver();
    }

    @Test
    public void testLogin() throws InterruptedException {
        // 1. Oldal megnyitása
        driver.get("https://www.demoncars.online/index.html");
         
        // 2. Bejelentkezés
        driver.findElement(By.id("user-icon")).click();
        driver.findElement(By.id("user")).sendKeys("Teszt Elek");
        driver.findElement(By.id("password")).sendKeys("Tesztjelszo123!");
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        
        // 3. Rövid várakozás
        Thread.sleep(2000);
        
        // 4. Ellenőrzés
        if(driver.getCurrentUrl().equals("https://www.demoncars.online/index.html")) {
            System.out.println("Sikeres bejelentkezés!");
        } else {
            System.out.println("Sikertelen bejelentkezés!");
        }
    }

    
}


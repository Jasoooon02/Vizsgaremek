
package com.mycompany.demoncars;

import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.*;

import org.openqa.selenium.edge.EdgeDriver;

public class DemoncarsregistrationTest {


    private WebDriver driver;

    @BeforeEach
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        driver = new EdgeDriver();
    }

    @Test
    public void testRegistration() {
        driver.get("https://www.demoncars.online/");
        
        // Regisztráció megnyitása
        driver.findElement(By.id("user-icon")).click();
        
        // Űrlap kitöltése
        driver.findElement(By.id("reg-email")).sendKeys("teszt.elek@gmail.com");
        driver.findElement(By.id("reg-username")).sendKeys("Teszt Elek");
        driver.findElement(By.id("reg-password")).sendKeys("TesztJelszo123!");
        driver.findElement(By.id("confirm-password")).sendKeys("TesztJelszo123!");
        
        // Regisztráció elküldése
        driver.findElement(By.xpath("//form[@id='register-form']/button")).click();
        
        // Sikeres regisztráció ellenőrzése
        try {
            Thread.sleep(2000); // Várakozás
            assertTrue(driver.findElement(By.id("welcome-message")).isDisplayed());
        } catch (Exception e) {
            fail("Regisztráció sikertelen: " + e.getMessage());
        }
    }

   
}



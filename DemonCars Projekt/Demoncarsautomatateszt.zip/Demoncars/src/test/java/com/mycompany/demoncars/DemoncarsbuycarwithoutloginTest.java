
package com.mycompany.demoncars;

import org.openqa.selenium.*;
import java.time.Duration;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.edge.EdgeDriver;
public class DemoncarsbuycarwithoutloginTest {
    

  private WebDriver driver;
 
  
  private StringBuffer verificationErrors = new StringBuffer();
  JavascriptExecutor js;
  @BeforeEach
  public void setUp() throws Exception {
    System.setProperty("webdriver.chrome.driver", "");
    driver = new EdgeDriver();
    
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
    js = (JavascriptExecutor) driver;
  }

  @Test
  public void testUntitledTestCase() throws Exception {
    driver.get("https://www.demoncars.online/index.html");
      Thread.sleep(2000);
    driver.findElement(By.xpath("//img[@alt='Porsche 911 GT3']")).click();
      Thread.sleep(2000);
    driver.get("https://www.demoncars.online/gt3.html");
    driver.findElement(By.id("add-to-cart-btn")).click();
      Thread.sleep(2000);
    driver.findElement(By.id("cart-btn")).click();
      Thread.sleep(2000);
    driver.findElement(By.id("checkout-btn")).click();
      Thread.sleep(2000);
    driver.get("https://www.demoncars.online/login.html");
  }

  @AfterEach
  public void tearDown() throws Exception {
  
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

 
}





package com.mycompany.demoncars;

import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.edge.EdgeDriver;
public class DemoncarsbuycarwithloginTest {
   
  private WebDriver driver;
  
 
  private StringBuffer verificationErrors = new StringBuffer();
  JavascriptExecutor js;
  @BeforeEach
  public void setUp() throws Exception {
    System.setProperty("webdriver.chrome.driver", "");
    driver = new EdgeDriver();
    
    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
    js = (JavascriptExecutor) driver;
  }

  @Test
  public void testUntitledTestCase() throws Exception {
    driver.get("https://www.demoncars.online/index.html");
    driver.findElement(By.id("user-icon")).click();
    driver.get("https://www.demoncars.online/login.html");
    driver.findElement(By.id("user")).click();
    driver.findElement(By.id("user")).clear();
    driver.findElement(By.id("user")).sendKeys("Teszt Elek");
    driver.findElement(By.id("password")).click();
    driver.findElement(By.id("password")).clear();
    driver.findElement(By.id("password")).sendKeys("Tesztjelszo123!");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.get("https://www.demoncars.online/login.php");
    driver.get("https://www.demoncars.online/index.html");
    driver.findElement(By.xpath("//img[@alt='Porsche 911 GT3']")).click();
    driver.get("https://www.demoncars.online/gt3.html");
    driver.findElement(By.id("add-to-cart-btn")).click();
    driver.findElement(By.id("cart-btn")).click();
    driver.findElement(By.id("checkout-btn")).click();
    driver.get("https://www.demoncars.online/checkout.html");
    driver.findElement(By.id("name")).click();
    driver.findElement(By.id("name")).clear();
    driver.findElement(By.id("name")).sendKeys("Teszt Elek");
    driver.findElement(By.id("address")).click();
    driver.findElement(By.id("address")).clear();
    driver.findElement(By.id("address")).sendKeys("rét utca 42");
    driver.findElement(By.id("phone")).click();
    driver.findElement(By.id("phone")).clear();
    driver.findElement(By.id("phone")).sendKeys("06 30 732 5678");
    driver.findElement(By.xpath("//button[@type='submit']")).click();
    driver.get("https://www.demoncars.online/submit-order.php");
    driver.get("https://www.demoncars.online/index.html");
  }

  @AfterEach
  public void tearDown() throws Exception {
    
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.demoncars;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.fail;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.edge.EdgeDriver;

public class DCforgatpasswordwrongdataTest {
    
private WebDriver driver;
  
  
  private StringBuffer verificationErrors = new StringBuffer();
  JavascriptExecutor js;
  @BeforeEach
  public void setUp() throws Exception {
    System.setProperty("webdriver.chrome.driver", "");
    driver = new EdgeDriver();

    driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(60));
    js = (JavascriptExecutor) driver;
  }

  @Test
  public void testUntitledTestCase() throws Exception {
    driver.get("https://www.demoncars.online/index.html");
    driver.findElement(By.id("user-icon")).click();
    driver.get("https://www.demoncars.online/login.html");
    driver.findElement(By.id("forgot-password-link")).click();
    driver.findElement(By.id("fp-username")).click();
    driver.findElement(By.id("fp-username")).clear();
    driver.findElement(By.id("fp-username")).sendKeys("Teszt");
    driver.findElement(By.id("fp-email")).click();
    driver.findElement(By.id("fp-email")).clear();
    driver.findElement(By.id("fp-email")).sendKeys("teszt.elek@gmail.com");
    driver.findElement(By.name("action")).click();
    driver.get("https://www.demoncars.online/forgot_verify.html?email=teszt.elek%40gmail.com");
  }

  @AfterEach
  public void tearDown() throws Exception {

    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

}

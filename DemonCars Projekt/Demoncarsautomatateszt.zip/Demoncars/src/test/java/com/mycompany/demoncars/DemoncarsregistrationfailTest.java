
package com.mycompany.demoncars;

import org.junit.jupiter.api.*;
import org.openqa.selenium.*;
import org.openqa.selenium.edge.EdgeDriver;

public class DemoncarsregistrationfailTest {
    private WebDriver driver;

    @BeforeEach
    public void setup() {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe"); // vagy a teljes elérési út
        driver = new EdgeDriver();
    }

    @Test
    public void testPasswordMismatch() {
        try {
            // 1. Oldal megnyitása
            driver.get("https://www.demoncars.online/");
            
            // 2. Regisztrációs űrlap megnyitása
            driver.findElement(By.id("user-icon")).click();
            
            // 3. Adatok kitöltése
            driver.findElement(By.id("reg-email")).sendKeys("teszt.elek@gmail.com");
            driver.findElement(By.id("reg-username")).sendKeys("Teszt Elek");
            driver.findElement(By.id("reg-password")).sendKeys("Jelszo123");
            driver.findElement(By.id("confirm-password")).sendKeys("NemEgyezik456");
            
            // 4. Regisztráció elküldése
            driver.findElement(By.xpath("//form[@id='register-form']/button")).click();
            
            // 5. Rövid várakozás
            Thread.sleep(2000);
            
            // 6. Hibaüzenet ellenőrzése (a legegyszerűbb módon)
            if(driver.findElements(By.className("error-message")).size() == 0) {
                throw new AssertionError("Nem jelenik meg hibaüzenet!");
            }
            
        } catch (InterruptedException e) {
            Assertions.fail("A teszt megszakadt: " + e.getMessage());
        } catch (Exception e) {
            Assertions.fail("Hiba történt: " + e.getMessage());
        }
    }

    
}
    
